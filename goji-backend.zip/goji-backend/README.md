# GOJI AI · Backend propio (Render)

Un solo servicio de Render que hace dos cosas: **sirve la aplicación GOJI AI** (`public/index.html`) y expone una **API segura** (`/api/*`) que habla con OpenAI, Anthropic, Gemini y DeepSeek. Las claves viven solo en variables de entorno de Render.

> Importante: la versión publicada en claude.ai NO puede usar este backend (su política de seguridad bloquea peticiones a otros sitios). Usa GOJI AI desde la URL de Render. La versión de claude.ai sigue funcionando con su Claude integrado.

## Despliegue en Render

1. Crea un repositorio en GitHub (privado recomendado) y sube el contenido de esta carpeta (`server.js`, `package.json`, `render.yaml`, `public/`, `.gitignore`). **No subas `.env`.**
2. En https://render.com: **New → Web Service** → conecta el repositorio.
   - Runtime: Node · Build Command: `npm install` · Start Command: `node server.js`
   - (Si prefieres, **New → Blueprint** y usa `render.yaml`.)
3. En **Environment** añade estas variables:

| Variable | Obligatoria | Valor |
|---|---|---|
| `GOJI_ACCESS_CODE` | Sí | Un código largo y secreto que inventes. Sin él, el servidor rechaza todo. |
| `ALLOWED_ORIGIN` | Solo si sirves el frontend desde otro dominio | URL con https, sin barra final. Varias, separadas por comas. El propio dominio de Render ya está permitido. |
| `OPENAI_API_KEY` | Para ChatGPT | Clave de https://platform.openai.com |
| `ANTHROPIC_API_KEY` | Para Claude | Clave de https://console.anthropic.com |
| `GEMINI_API_KEY` | Para Gemini | Clave de https://aistudio.google.com |
| `DEEPSEEK_API_KEY` | Para DeepSeek | Clave de https://platform.deepseek.com |
| `*_MODEL` (opcional) | No | `OPENAI_MODEL`, `ANTHROPIC_MODEL`, `GEMINI_MODEL`, `DEEPSEEK_MODEL`. Si un modelo por defecto ya no existe, el error del proveedor te lo dirá: pon aquí uno vigente. |

4. Despliega. Abre `https://TU-SERVICIO.onrender.com` → **IA Hub** → panel «Servidor propio»: deja la URL vacía, escribe tu código de acceso y pulsa **Guardar y conectar**.
5. En cada proveedor con clave pulsa **Probar**. Solo aparece «API conectada» si el proveedor devolvió una respuesta real. Si no, verás el código y el mensaje del fallo.

Notas: las claves de API son un servicio aparte de las suscripciones (ChatGPT Plus, Claude Pro… no las incluyen) y se pagan por uso. En el plan gratuito de Render el servicio se duerme y la primera petición tarda. Si activas «Enviar mis datos como contexto», tus proyectos, ideas, películas y juegos (sin imágenes) se envían al proveedor elegido.

## Prueba local
```
npm install
GOJI_ACCESS_CODE=prueba ANTHROPIC_API_KEY=... node server.js   # http://localhost:3000
```

## Endpoints
- `GET /api/health` público, sin datos sensibles.
- `GET /api/providers` (cabecera `X-Goji-Code`) estado de cada proveedor: solo si hay clave, nunca la clave.
- `POST /api/chat` (cabecera `X-Goji-Code`) cuerpo `{provider, messages:[{role,content}], system?}` → `{text}` o `{error:{code,message}}`.

Errores posibles: `bad_code`, `no_access_code`, `missing_key`, `provider_error`, `provider_timeout`, `provider_unreachable`, `empty_response`, `origin_not_allowed`, `rate_limited`, `bad_messages`.
