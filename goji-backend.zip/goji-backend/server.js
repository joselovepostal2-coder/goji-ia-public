'use strict';
const express = require('express');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1); // Render va detrás de un proxy HTTPS

const PORT = process.env.PORT || 3000;
const CODE = process.env.GOJI_ACCESS_CODE || '';
const ORIGINS = (process.env.ALLOWED_ORIGIN || '').split(',').map(s => s.trim().replace(/\/+$/, '')).filter(Boolean);

// Las claves SOLO se leen de variables de entorno, nunca se devuelven al cliente ni se escriben en logs.
const P = {
  openai:    { name: 'ChatGPT (OpenAI)',    env: 'OPENAI_API_KEY',    model: process.env.OPENAI_MODEL    || 'gpt-4o-mini' },
  anthropic: { name: 'Claude (Anthropic)',  env: 'ANTHROPIC_API_KEY', model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5' },
  gemini:    { name: 'Gemini (Google)',     env: 'GEMINI_API_KEY',    model: process.env.GEMINI_MODEL    || 'gemini-2.5-flash' },
  deepseek:  { name: 'DeepSeek',            env: 'DEEPSEEK_API_KEY',  model: process.env.DEEPSEEK_MODEL  || 'deepseek-chat' }
};

const err = (code, message) => ({ error: { code, message } });

// Cabeceras de seguridad y política del frontend servido por este mismo servidor
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  next();
});

// CORS: solo el propio dominio y los orígenes listados en ALLOWED_ORIGIN
app.use('/api', (req, res, next) => {
  const o = req.headers.origin;
  if (o) {
    const own = req.protocol + '://' + req.headers.host;
    if (o !== own && !ORIGINS.includes(o)) return res.status(403).json(err('origin_not_allowed', 'Origen no autorizado.'));
    res.setHeader('Access-Control-Allow-Origin', o);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Goji-Code');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// Limitador simple en memoria por IP
const hits = new Map();
function limiter(name, max, windowMs) {
  return (req, res, next) => {
    const k = name + ':' + req.ip, now = Date.now();
    const arr = (hits.get(k) || []).filter(t => now - t < windowMs);
    if (arr.length >= max) return res.status(429).json(err('rate_limited', 'Demasiadas peticiones. Espera un momento.'));
    arr.push(now); hits.set(k, arr); next();
  };
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (!v.some(t => now - t < 600000)) hits.delete(k); }, 300000).unref();

// Autenticación por código de acceso (comparación en tiempo constante)
function auth(req, res, next) {
  if (!CODE) return res.status(503).json(err('no_access_code', 'El servidor no tiene configurada la variable GOJI_ACCESS_CODE en Render.'));
  const a = Buffer.from(String(req.headers['x-goji-code'] || '')), b = Buffer.from(CODE);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json(err('bad_code', 'Código de acceso incorrecto o ausente.'));
  next();
}

app.get('/api/health', (req, res) => res.json({ app: 'goji-backend', ok: true }));

app.get('/api/providers', limiter('auth', 60, 600000), auth, (req, res) => {
  const providers = {};
  for (const [id, p] of Object.entries(P)) providers[id] = { name: p.name, env: p.env, model: p.model, configured: !!process.env[p.env] };
  res.json({ ok: true, providers });
});

// Construcción de cada petición según la documentación oficial de cada API
const msgsToGemini = m => m.map(x => ({ role: x.role === 'assistant' ? 'model' : 'user', parts: [{ text: x.content }] }));
const spec = {
  openai:   (k, m, msgs, sys) => ({ url: 'https://api.openai.com/v1/chat/completions', h: { Authorization: 'Bearer ' + k }, b: { model: m, messages: sys ? [{ role: 'system', content: sys }, ...msgs] : msgs }, x: d => d.choices?.[0]?.message?.content }),
  deepseek: (k, m, msgs, sys) => ({ url: 'https://api.deepseek.com/chat/completions', h: { Authorization: 'Bearer ' + k }, b: { model: m, messages: sys ? [{ role: 'system', content: sys }, ...msgs] : msgs }, x: d => d.choices?.[0]?.message?.content }),
  anthropic:(k, m, msgs, sys) => ({ url: 'https://api.anthropic.com/v1/messages', h: { 'x-api-key': k, 'anthropic-version': '2023-06-01' }, b: { model: m, max_tokens: 2048, messages: msgs, ...(sys ? { system: sys } : {}) }, x: d => (d.content || []).filter(c => c.type === 'text').map(c => c.text).join('') }),
  gemini:   (k, m, msgs, sys) => ({ url: 'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(m) + ':generateContent', h: { 'x-goog-api-key': k }, b: { contents: msgsToGemini(msgs), ...(sys ? { systemInstruction: { parts: [{ text: sys }] } } : {}) }, x: d => (d.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('') })
};

function providerMessage(body, raw) {
  const e = body?.error;
  return String((typeof e === 'string' ? e : e?.message) || body?.message || raw || 'sin detalle').slice(0, 300);
}

app.post('/api/chat', limiter('auth', 60, 600000), auth, limiter('chat', 30, 60000), express.json({ limit: '256kb' }), async (req, res) => {
  const { provider, messages, system } = req.body || {};
  const p = P[provider];
  if (!p) return res.status(400).json(err('bad_provider', 'Proveedor desconocido.'));
  if (!Array.isArray(messages) || !messages.length || messages.length > 30 ||
      !messages.every(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.length > 0 && m.content.length < 30000) ||
      messages[0].role !== 'user' || messages[messages.length - 1].role !== 'user')
    return res.status(400).json(err('bad_messages', 'Mensajes no válidos: deben alternar usuario/asistente, empezar y terminar con el usuario.'));
  if (system !== undefined && (typeof system !== 'string' || system.length > 30000)) return res.status(400).json(err('bad_system', 'El contexto es demasiado largo.'));
  const key = process.env[p.env];
  if (!key) return res.status(503).json(err('missing_key', `Falta la variable ${p.env} en Render. Añádela en Environment y vuelve a desplegar.`));

  const s = spec[provider](key, p.model, messages, system);
  try {
    const r = await fetch(s.url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...s.h }, body: JSON.stringify(s.b), signal: AbortSignal.timeout(60000) });
    const raw = await r.text();
    let data = null; try { data = JSON.parse(raw); } catch (_) {}
    if (!r.ok) return res.status(502).json(err('provider_error', `${p.name} respondió HTTP ${r.status}: ${providerMessage(data, raw)}`));
    const text = data && s.x(data);
    if (!text) return res.status(502).json(err('empty_response', `${p.name} no devolvió texto en la respuesta.`));
    res.json({ text, provider, model: p.model });
  } catch (e) {
    const timeout = e.name === 'TimeoutError' || e.name === 'AbortError';
    res.status(504).json(err(timeout ? 'provider_timeout' : 'provider_unreachable', timeout ? `${p.name} tardó más de 60 s en responder.` : `No se pudo contactar con ${p.name} (${e.cause?.code || e.message}).`));
  }
});

app.use('/api', (req, res) => res.status(404).json(err('not_found', 'Endpoint no encontrado.')));
app.use((e, req, res, next) => res.status(400).json(err('bad_request', 'Petición no válida.'))); // JSON mal formado, etc.
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log(`GOJI backend en puerto ${PORT}`);
  console.log('Código de acceso:', CODE ? 'configurado' : 'FALTA GOJI_ACCESS_CODE');
  for (const p of Object.values(P)) console.log(`${p.name}:`, process.env[p.env] ? 'clave configurada' : `falta ${p.env}`);
});
