# GOJI AI 1.0.10: reparación del menú que no cargaba

## Causa exacta (1.0.9)
En `index.html`, objeto `IC` (iconos del menú), faltaba una comilla de cierre después del icono `data`
(`...v-6"/>,book:'...` en lugar de `...v-6"/>',book:'...`). Eso es un **error de sintaxis**: el navegador
descarta TODO el script principal, así que `render()` nunca se ejecuta y `#rail` y `#main` quedan vacíos
(pantalla negra con el fondo del tema). Los elementos `#rail`/`#main` sí existían; IndexedDB, `local-server.js`
y `electron-main.js` no eran la causa. El `.exe` 1.0.9 que subiste contiene exactamente ese mismo `index.html`.

## Cambios (nada eliminado)
**index.html**
- Corregida la comilla que rompía el script.
- Icono de «Enciclopedia»: usaba la clave `library`, que no existía en `IC` (mostraba `undefined`); ahora usa el icono `book`.
- Guardia de arranque independiente (script aparte, antes del principal): si la interfaz no se dibuja en 6 s
  o el arranque falla, muestra una pantalla de recuperación con el error real y 4 opciones: Reintentar,
  Descargar copia en bruto de tus datos, Restaurar desde copia .json y Restablecer datos (con confirmación).
- Errores de JavaScript posteriores al arranque ahora se ven en una barra inferior (antes eran silenciosos).
- `render()` comprueba que existan `#rail` y `#main`; si una sección falla al dibujarse, muestra el error en esa sección
  y el menú sigue funcionando.
- Lectura de IndexedDB con límite de 3 s, detección de bloqueo y mensajes claros. Si no se pueden leer los datos,
  el guardado queda **en pausa** para no sobrescribir lo que haya guardado, con botones Reintentar / Continuar sin datos.
- Los datos guardados se validan al iniciar (listas, tareas, objetos). Lo dañado se corrige, se avisa en pantalla y se
  guarda una copia en bruto del original (botón «Descargar copia en bruto»).

**electron-main.js**: registro en `%APPDATA%\GOJI AI\goji-log.txt` (errores de carga, errores de consola del renderer,
caídas del proceso); página de error en lugar de ventana negra si falla la carga; aviso de recarga si el proceso gráfico
se cierra; mensaje específico si el puerto 3000 está ocupado o lo usa otra versión de GOJI AI.

**local-server.js**: `/api/health` informa la versión; detecta y reporta `EADDRINUSE`.

**package.json**: versión 1.0.10.

## Pruebas realizadas (en Node con jsdom + IndexedDB simulado)
Con el `index.html` original: error de sintaxis y menú vacío (reproducido). Con el corregido: arranque limpio, 10 secciones
cargan sin errores, persistencia tras reabrir, datos dañados (`projects` nulo, elementos nulos, texto), IndexedDB ausente
o que nunca responde, y la pantalla de recuperación con un script roto.
**No probado:** ejecución real dentro de Electron/Windows y el empaquetado `.exe` (aquí no hay Windows ni Electron).
Los cambios de `electron-main.js` solo pasaron revisión de sintaxis.

## Cómo generar el .exe
Copia los 4 archivos al repositorio, haz commit a `main` y GitHub Actions («Build GOJI AI for Windows») generará
`GOJI-AI-1.0.10-Windows-Portable.exe` como artefacto. O en Windows: `npm install` y `npm run dist:win`.
Tus datos están en IndexedDB del perfil de usuario y se conservan al cambiar de versión mientras la app siga en `http://127.0.0.1:3000`.
