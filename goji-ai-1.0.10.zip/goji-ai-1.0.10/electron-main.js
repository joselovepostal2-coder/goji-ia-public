"use strict";

const { app, BrowserWindow, shell, desktopCapturer, dialog, session } = require("electron");
const path = require("path");
const fs = require("fs");

// Registro de diagnóstico en el perfil del usuario (Windows: %APPDATA%\GOJI AI\goji-log.txt).
function logFile() { return path.join(app.getPath("userData"), "goji-log.txt"); }
function log(message) {
  try {
    const file = logFile();
    try { if (fs.statSync(file).size > 512 * 1024) fs.writeFileSync(file, ""); } catch {}
    fs.appendFileSync(file, new Date().toISOString() + "  " + message + "\n");
  } catch {}
}
function errorPage(title, detail) {
  const esc = t => String(t).replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  const html = "<meta charset=utf-8><body style=\"margin:0;background:#04050a;color:#e8ecf8;font:16px Segoe UI,sans-serif;display:grid;place-items:center;height:100vh\"><div style=\"max-width:640px;padding:24px\"><div style=\"color:#e2b64d;letter-spacing:.3em;font-weight:800\">GOJI AI</div><h2>" + esc(title) + "</h2><p style=\"color:#ff9aa5;white-space:pre-wrap\">" + esc(detail) + "</p><p style=\"color:#7f8aa8\">Tus datos no se han borrado. Registro: " + esc(logFile()) + "</p><a href=\"http://127.0.0.1:3000\" style=\"color:#fff;background:#2f6bff;padding:10px 16px;border-radius:8px;text-decoration:none\">Reintentar</a></div></body>";
  return "data:text/html;charset=utf-8," + encodeURIComponent(html);
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    const win = BrowserWindow.getAllWindows()[0];
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
  });

  app.whenReady().then(async () => {
    // Keep the API key outside the packaged application, in the user's Windows profile.
    process.env.GOJI_CONFIG_PATH = path.join(app.getPath("userData"), ".goji-local.json");
    process.env.GOJI_LOCAL_PORT = "3000";

    // The same local backend used by the browser version.
    const gojiServer = require("./local-server.js");
    log("Inicio de GOJI AI " + app.getVersion());

    const win = new BrowserWindow({
      width: 1360,
      height: 900,
      minWidth: 900,
      minHeight: 620,
      title: "GOJI AI · Goji Empires",
      backgroundColor: "#04050a",
      autoHideMenuBar: true,
      webPreferences: {
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true
      }
    });

    // Grant media permissions only to GOJI's own loopback page.
    // The page still asks through an explicit user action before opening camera/microphone.
    const isGojiOrigin = (origin) => {
      try { return new URL(origin).origin === "http://127.0.0.1:3000"; }
      catch { return false; }
    };
    session.defaultSession.setPermissionRequestHandler((webContents, permission, callback, details) => {
      const origin = details?.requestingUrl || details?.securityOrigin || webContents.getURL();
      if (!isGojiOrigin(origin)) { callback(false); return; }
      if (permission === "media") {
        const types = details?.mediaTypes || [];
        callback(types.includes("audio") || types.includes("video"));
        return;
      }
      if (permission === "display-capture") {
        callback(true);
        return;
      }
      callback(false);
    });
    session.defaultSession.setPermissionCheckHandler((webContents, permission, requestingOrigin, details) => {
      if (!isGojiOrigin(requestingOrigin || webContents?.getURL())) return false;
      if (permission === "media") {
        const types = details?.mediaType ? [details.mediaType] : [];
        return types.includes("audio") || types.includes("video");
      }
      return permission === "display-capture";
    });

    // Electron requires an explicit handler for getDisplayMedia.
    // Show a native Windows dialog so the user chooses which monitor to share.
    session.defaultSession.setDisplayMediaRequestHandler(async (_request, callback) => {
      try {
        const sources = await desktopCapturer.getSources({
          types: ["screen"],
          thumbnailSize: { width: 320, height: 180 }
        });
        if (!sources.length) {
          callback({});
          return;
        }
        const buttons = sources.slice(0, 4).map((source, index) =>
          sources.length === 1 ? "Compartir pantalla" : "Pantalla " + (index + 1)
        );
        buttons.push("Cancelar");
        const choice = await dialog.showMessageBox(win, {
          type: "question",
          title: "GOJI AI · Transmisor",
          message: "¿Qué pantalla quieres compartir?",
          buttons,
          cancelId: buttons.length - 1,
          defaultId: 0,
          noLink: true
        });
        if (choice.response < 0 || choice.response >= sources.length || choice.response >= 4) {
          callback({});
          return;
        }
        callback({ video: sources[choice.response] });
      } catch (error) {
        console.error("GOJI screen capture:", error);
        callback({});
      }
    });

    // Evita ventanas negras mudas: registra y muestra cualquier fallo de carga o cierre del proceso gráfico.
    win.webContents.on("did-fail-load", (_e, code, description, url, isMainFrame) => {
      if (!isMainFrame || code === -3) return;
      log("did-fail-load " + code + " " + description + " " + url);
      win.loadURL(errorPage("No se pudo cargar la interfaz", description + " (código " + code + ")"));
    });
    win.webContents.on("render-process-gone", (_e, details) => {
      log("render-process-gone: " + details.reason);
      dialog.showMessageBox(win, { type: "error", message: "La ventana de GOJI AI se cerró inesperadamente (" + details.reason + ").", buttons: ["Recargar", "Salir"], defaultId: 0, cancelId: 1 })
        .then(r => { if (r.response === 0) win.reload(); else app.quit(); });
    });
    win.webContents.on("console-message", (...args) => {
      const d = args[0] && args[0].message !== undefined ? args[0] : { level: args[1], message: args[2], lineNumber: args[3], sourceId: args[4] };
      if (d.level === "error" || d.level === 3) log("renderer error: " + d.message + " (" + d.sourceId + ":" + d.lineNumber + ")");
    });

    win.webContents.setWindowOpenHandler(({ url }) => {
      if (url.startsWith("https://") || url.startsWith("http://")) shell.openExternal(url);
      return { action: "deny" };
    });

    // Wait for the loopback server before loading the interface.
    let ready = false, remoteVersion = "";
    for (let attempt = 0; attempt < 40; attempt++) {
      try {
        const response = await fetch("http://127.0.0.1:3000/api/health");
        if (response.ok) {
          const body = await response.json().catch(() => ({}));
          if (body && body.service === "GOJI AI local") { ready = true; remoteVersion = body.version || ""; break; }
        }
      } catch {}
      await new Promise(resolve => setTimeout(resolve, 250));
    }

    if (!ready) {
      const e = gojiServer && gojiServer.error;
      const why = e && e.code === "EADDRINUSE"
        ? "El puerto 3000 está ocupado por otro programa (por ejemplo otra copia de GOJI AI o el servidor local abierto con el .bat). Ciérralo e inténtalo de nuevo."
        : e ? "Error del servidor local: " + e.message : "El servidor local no respondió a tiempo.";
      log("Arranque fallido: " + why);
      dialog.showErrorBox("GOJI AI", why + "\n\nRegistro: " + logFile());
      app.quit();
      return;
    }
    if (remoteVersion && remoteVersion !== app.getVersion()) {
      const why = "Otra copia de GOJI AI (versión " + remoteVersion + ") ya está usando el puerto 3000 y mostraría una interfaz distinta. Ciérrala e inténtalo de nuevo.";
      log("Arranque cancelado: " + why);
      dialog.showErrorBox("GOJI AI", why + "\n\nRegistro: " + logFile());
      app.quit();
      return;
    }

    try { await win.loadURL("http://127.0.0.1:3000"); }
    catch (error) { log("loadURL falló: " + error.message); await win.loadURL(errorPage("No se pudo cargar la interfaz", error.message)); }
  });

  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") app.quit();
  });
}
